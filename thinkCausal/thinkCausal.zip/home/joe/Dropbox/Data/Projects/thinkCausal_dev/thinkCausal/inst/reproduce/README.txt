Reproducible script instructions

-Unzip this folder and save all files to a local folder.
-Save your dataset to the newly created folder
-Open 'thinkCausal_script.R' using Rstudio and ensure the working directory (setwd()) is set to the newly created folder.
-Execute each line individually or click 'Run' in the top right of the Rstudio script editor.
